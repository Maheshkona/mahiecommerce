using BookStore.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Web.Controllers
{
    public class ProductsController : Controller
    {
        private readonly IProductService _products;
        public ProductsController(IProductService products) => _products = products;

        public async Task<IActionResult> Index(string? search, int? categoryId)
        {
            ViewBag.Categories = await _products.GetCategoriesAsync();
            var list = await _products.GetAllAsync(search, categoryId);
            return View(list);
        }

        public async Task<IActionResult> Details(int id)
        {
            var p = await _products.GetByIdAsync(id);
            if (p == null) return NotFound();
            return View(p);
        }
    }
}
