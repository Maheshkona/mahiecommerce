using System.Security.Claims;
using BookStore.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Web.Controllers
{
    [Authorize]
    public class CartController : Controller
    {
        private readonly ICartService _cart;
        private readonly IOrderService _orders;
        private readonly IPaymentService _payments;

        public CartController(ICartService cart, IOrderService orders, IPaymentService payments)
        {
            _cart = cart;
            _orders = orders;
            _payments = payments;
        }

        private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        [HttpPost]
        public async Task<IActionResult> Add(int productId, int quantity = 1)
        {
            await _cart.AddToCartAsync(CurrentUserId, productId, quantity);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Index()
        {
            var items = await _cart.GetCartAsync(CurrentUserId);
            ViewBag.Total = await _cart.GetCartTotalAsync(CurrentUserId);
            return View(items);
        }

        [HttpPost]
        public async Task<IActionResult> Remove(int productId)
        {
            await _cart.RemoveFromCartAsync(CurrentUserId, productId);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> Checkout()
        {
            var order = await _orders.CreateOrderAsync(CurrentUserId);
            var payment = await _payments.ProcessPaymentAsync(order.OrderId, order.TotalAmount);
            return RedirectToAction("Success", "Orders", new { id = order.OrderId });
        }
    }
}
