using System.Security.Claims;
using BookStore.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Web.Controllers
{
    [Authorize]
    public class OrdersController : Controller
    {
        private readonly IOrderService _orders;
        public OrdersController(IOrderService orders) => _orders = orders;

        private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        public async Task<IActionResult> My()
        {
            var list = await _orders.GetOrdersByUserAsync(CurrentUserId);
            return View(list);
        }

        public async Task<IActionResult> Details(int id)
        {
            var o = await _orders.GetOrderAsync(id);
            if (o == null) return NotFound();
            return View(o);
        }

        public IActionResult Success(int id) => View(model: id);
    }
}
