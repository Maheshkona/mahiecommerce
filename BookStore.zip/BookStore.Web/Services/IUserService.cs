using BookStore.Web.Models;

namespace BookStore.Web.Services
{
    public interface IUserService
    {
        Task<User?> GetByUsernameAsync(string username);
        Task<User?> GetByIdAsync(int id);
        Task<User> RegisterAsync(string username, string email, string password, UserRole role);
        Task<IEnumerable<User>> GetAllAsync();
    }
}
