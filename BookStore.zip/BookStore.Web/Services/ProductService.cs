using BookStore.Web.Data;
using BookStore.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Web.Services
{
    public class ProductService : IProductService
    {
        private readonly ApplicationDbContext _db;
        public ProductService(ApplicationDbContext db) => _db = db;

        public async Task<IEnumerable<Product>> GetAllAsync(string? search = null, int? categoryId = null)
        {
            var q = _db.Products.Include(p => p.Category).AsQueryable();
            if (!string.IsNullOrWhiteSpace(search))
                q = q.Where(p => p.Name.Contains(search));
            if (categoryId.HasValue)
                q = q.Where(p => p.CategoryId == categoryId.Value);
            return await q.OrderBy(p => p.Name).ToListAsync();
        }

        public Task<Product?> GetByIdAsync(int id) => _db.Products.Include(p => p.Category).FirstOrDefaultAsync(p => p.ProductId == id);

        public async Task<Product> CreateAsync(Product product)
        {
            _db.Products.Add(product);
            await _db.SaveChangesAsync();
            return product;
        }

        public async Task<Product?> UpdateAsync(Product product)
        {
            var existing = await _db.Products.FindAsync(product.ProductId);
            if (existing == null) return null;
            _db.Entry(existing).CurrentValues.SetValues(product);
            await _db.SaveChangesAsync();
            return existing;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var p = await _db.Products.FindAsync(id);
            if (p == null) return false;
            _db.Products.Remove(p);
            await _db.SaveChangesAsync();
            return true;
        }

        public Task<IEnumerable<Category>> GetCategoriesAsync()
            => Task.FromResult<IEnumerable<Category>>(_db.Categories.OrderBy(c => c.Name).ToList());
    }
}
