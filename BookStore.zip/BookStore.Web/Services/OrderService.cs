using BookStore.Web.Data;
using BookStore.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Web.Services
{
    public class OrderService : IOrderService
    {
        private readonly ApplicationDbContext _db;
        private readonly ICartService _cart;
        public OrderService(ApplicationDbContext db, ICartService cart)
        {
            _db = db;
            _cart = cart;
        }

        public async Task<Order> CreateOrderAsync(int userId)
        {
            var cartItems = await _db.CartItems.Include(c => c.Product).Where(c => c.UserId == userId).ToListAsync();
            if (!cartItems.Any()) throw new InvalidOperationException("Cart is empty");

            var order = new Order
            {
                UserId = userId,
                OrderDate = DateTime.UtcNow,
                Status = OrderStatus.PENDING,
                TotalAmount = cartItems.Sum(i => i.Product!.Price * i.Quantity),
                Items = cartItems.Select(ci => new OrderItem
                {
                    ProductId = ci.ProductId,
                    Quantity = ci.Quantity,
                    UnitPrice = ci.Product!.Price
                }).ToList()
            };

            _db.Orders.Add(order);
            await _db.SaveChangesAsync();
            await _cart.ClearCartAsync(userId);
            return order;
        }

        public Task<Order?> GetOrderAsync(int orderId) 
            => _db.Orders.Include(o => o.Items).ThenInclude(i => i.Product).FirstOrDefaultAsync(o => o.OrderId == orderId);

        public Task<IEnumerable<Order>> GetOrdersByUserAsync(int userId) 
            => Task.FromResult<IEnumerable<Order>>(_db.Orders.Where(o => o.UserId == userId).OrderByDescending(o => o.OrderDate).ToList());

        public Task<IEnumerable<Order>> GetAllOrdersAsync() 
            => Task.FromResult<IEnumerable<Order>>(_db.Orders.Include(o => o.User).OrderByDescending(o => o.OrderDate).ToList());

        public async Task UpdateStatusAsync(int orderId, OrderStatus status)
        {
            var order = await _db.Orders.FindAsync(orderId);
            if (order == null) return;
            order.Status = status;
            await _db.SaveChangesAsync();
        }
    }
}
