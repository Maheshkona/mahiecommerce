using BookStore.Web.Models;

namespace BookStore.Web.Services
{
    public interface IPaymentService
    {
        Task<Payment> ProcessPaymentAsync(int orderId, decimal amount);
        Task<Payment?> GetPaymentAsync(int paymentId);
    }
}
