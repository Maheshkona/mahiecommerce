using BookStore.Web.Models;

namespace BookStore.Web.Services
{
    public interface IProductService
    {
        Task<IEnumerable<Product>> GetAllAsync(string? search = null, int? categoryId = null);
        Task<Product?> GetByIdAsync(int id);
        Task<Product> CreateAsync(Product product);
        Task<Product?> UpdateAsync(Product product);
        Task<bool> DeleteAsync(int id);
        Task<IEnumerable<Category>> GetCategoriesAsync();
    }
}
