using BookStore.Web.Data;
using BookStore.Web.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Web.Services
{
    public class UserService : IUserService
    {
        private readonly ApplicationDbContext _db;
        private readonly IPasswordHasher<object> _hasher;

        public UserService(ApplicationDbContext db, IPasswordHasher<object> hasher)
        {
            _db = db;
            _hasher = hasher;
        }

        public Task<User?> GetByUsernameAsync(string username) 
            => _db.Users.FirstOrDefaultAsync(u => u.Username == username);

        public Task<User?> GetByIdAsync(int id) => _db.Users.FindAsync(id).AsTask();

        public async Task<User> RegisterAsync(string username, string email, string password, UserRole role)
        {
            if (await _db.Users.AnyAsync(u => u.Username == username))
                throw new InvalidOperationException("Username already exists");

            var user = new User
            {
                Username = username,
                Email = email,
                Role = role,
                PasswordHash = _hasher.HashPassword(new object(), password)
            };
            _db.Users.Add(user);
            await _db.SaveChangesAsync();
            return user;
        }

        public Task<IEnumerable<User>> GetAllAsync()
            => Task.FromResult<IEnumerable<User>>(_db.Users.OrderBy(u => u.Username).ToList());
    }
}
