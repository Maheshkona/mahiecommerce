using BookStore.Web.Models;

namespace BookStore.Web.Services
{
    public interface IOrderService
    {
        Task<Order> CreateOrderAsync(int userId);
        Task<Order?> GetOrderAsync(int orderId);
        Task<IEnumerable<Order>> GetOrdersByUserAsync(int userId);
        Task<IEnumerable<Order>> GetAllOrdersAsync();
        Task UpdateStatusAsync(int orderId, OrderStatus status);
    }
}
