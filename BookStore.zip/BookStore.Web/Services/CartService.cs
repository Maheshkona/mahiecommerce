using BookStore.Web.Data;
using BookStore.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Web.Services
{
    public class CartService : ICartService
    {
        private readonly ApplicationDbContext _db;
        public CartService(ApplicationDbContext db) => _db = db;

        public async Task AddToCartAsync(int userId, int productId, int quantity)
        {
            var item = await _db.CartItems.FirstOrDefaultAsync(c => c.UserId == userId && c.ProductId == productId);
            if (item == null)
            {
                item = new CartItem { UserId = userId, ProductId = productId, Quantity = quantity };
                _db.CartItems.Add(item);
            }
            else
            {
                item.Quantity += quantity;
            }
            await _db.SaveChangesAsync();
        }

        public async Task RemoveFromCartAsync(int userId, int productId)
        {
            var item = await _db.CartItems.FirstOrDefaultAsync(c => c.UserId == userId && c.ProductId == productId);
            if (item != null)
            {
                _db.CartItems.Remove(item);
                await _db.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<CartItem>> GetCartAsync(int userId)
        {
            return await _db.CartItems.Include(c => c.Product).Where(c => c.UserId == userId).ToListAsync();
        }

        public async Task ClearCartAsync(int userId)
        {
            var items = _db.CartItems.Where(c => c.UserId == userId);
            _db.CartItems.RemoveRange(items);
            await _db.SaveChangesAsync();
        }

        public async Task<decimal> GetCartTotalAsync(int userId)
        {
            var items = await GetCartAsync(userId);
            return items.Sum(i => i.Product!.Price * i.Quantity);
        }
    }
}
