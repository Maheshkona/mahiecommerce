using BookStore.Web.Models;

namespace BookStore.Web.Services
{
    public interface ICartService
    {
        Task AddToCartAsync(int userId, int productId, int quantity);
        Task RemoveFromCartAsync(int userId, int productId);
        Task<IEnumerable<CartItem>> GetCartAsync(int userId);
        Task ClearCartAsync(int userId);
        Task<decimal> GetCartTotalAsync(int userId);
    }
}
