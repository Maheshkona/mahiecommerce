using BookStore.Web.Data;
using BookStore.Web.Models;

namespace BookStore.Web.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly ApplicationDbContext _db;
        public PaymentService(ApplicationDbContext db) => _db = db;

        // Mock payment: always succeeds for demo
        public async Task<Payment> ProcessPaymentAsync(int orderId, decimal amount)
        {
            var payment = new Payment
            {
                OrderId = orderId,
                Amount = amount,
                PaymentStatus = PaymentStatus.COMPLETED,
                PaymentDate = DateTime.UtcNow
            };
            _db.Payments.Add(payment);
            await _db.SaveChangesAsync();
            return payment;
        }

        public Task<Payment?> GetPaymentAsync(int paymentId) => Task.FromResult(_db.Payments.Find(paymentId));
    }
}
