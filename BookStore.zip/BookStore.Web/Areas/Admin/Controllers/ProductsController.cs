using BookStore.Web.Models;
using BookStore.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "ADMIN")]
    public class ProductsController : Controller
    {
        private readonly IProductService _products;
        public ProductsController(IProductService products) => _products = products;

        public async Task<IActionResult> Index() => View(await _products.GetAllAsync());

        public async Task<IActionResult> Create()
        {
            ViewBag.Categories = await _products.GetCategoriesAsync();
            return View(new Product());
        }

        [HttpPost]
        public async Task<IActionResult> Create(Product model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Categories = await _products.GetCategoriesAsync();
                return View(model);
            }
            await _products.CreateAsync(model);
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id)
        {
            var p = await _products.GetByIdAsync(id);
            if (p == null) return NotFound();
            ViewBag.Categories = await _products.GetCategoriesAsync();
            return View(p);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Product model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Categories = await _products.GetCategoriesAsync();
                return View(model);
            }
            await _products.UpdateAsync(model);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            await _products.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
