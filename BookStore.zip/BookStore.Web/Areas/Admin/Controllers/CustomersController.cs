using BookStore.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "ADMIN")]
    public class CustomersController : Controller
    {
        private readonly IUserService _users;
        public CustomersController(IUserService users) => _users = users;

        public async Task<IActionResult> Index()
        {
            var list = await _users.GetAllAsync();
            return View(list.Where(u => u.Role.ToString() == "CUSTOMER"));
        }
    }
}
