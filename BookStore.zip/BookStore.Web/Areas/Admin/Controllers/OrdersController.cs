using BookStore.Web.Models;
using BookStore.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "ADMIN")]
    public class OrdersController : Controller
    {
        private readonly IOrderService _orders;
        public OrdersController(IOrderService orders) => _orders = orders;

        public async Task<IActionResult> Index() => View(await _orders.GetAllOrdersAsync());

        public async Task<IActionResult> Details(int id)
        {
            var order = await _orders.GetOrderAsync(id);
            if (order == null) return NotFound();
            return View(order);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateStatus(int id, OrderStatus status)
        {
            await _orders.UpdateStatusAsync(id, status);
            return RedirectToAction(nameof(Details), new { id });
        }
    }
}
