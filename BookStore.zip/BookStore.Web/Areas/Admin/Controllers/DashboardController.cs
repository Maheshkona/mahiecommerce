using BookStore.Web.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BookStore.Web.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "ADMIN")]
    public class DashboardController : Controller
    {
        private readonly IProductService _products;
        private readonly IOrderService _orders;
        private readonly IUserService _users;

        public DashboardController(IProductService products, IOrderService orders, IUserService users)
        {
            _products = products;
            _orders = orders;
            _users = users;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.ProductCount = (await _products.GetAllAsync()).Count();
            ViewBag.OrderCount = (await _orders.GetAllOrdersAsync()).Count();
            ViewBag.CustomerCount = (await _users.GetAllAsync()).Count(u => u.Role.ToString() == "CUSTOMER");
            return View();
        }
    }
}
