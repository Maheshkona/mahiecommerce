using BookStore.Web.Models;
using Microsoft.AspNetCore.Identity;

namespace BookStore.Web.Data
{
    public static class Seed
    {
        public static async Task RunAsync(ApplicationDbContext db, IPasswordHasher<object> hasher)
        {
            if (!db.Users.Any())
            {
                var admin = new User
                {
                    Username = "admin",
                    Email = "admin@bookstore.com",
                    Role = UserRole.ADMIN,
                    PasswordHash = "" // set below
                };
                admin.PasswordHash = hasher.HashPassword(new object(), "Admin@123");

                var customer = new User
                {
                    Username = "john",
                    Email = "john@example.com",
                    Role = UserRole.CUSTOMER,
                    PasswordHash = hasher.HashPassword(new object(), "John@123")
                };

                db.Users.AddRange(admin, customer);
            }

            if (!db.Categories.Any())
            {
                var fiction = new Category { Name = "Fiction" };
                var tech = new Category { Name = "Technology" };
                var sci = new Category { Name = "Science" };
                db.Categories.AddRange(fiction, tech, sci);
                await db.SaveChangesAsync();

                db.Products.AddRange(
                    new Product { Name = "The Alchemist", Description = "A novel by Paulo Coelho.", Price = 299, StockQuantity = 50, CategoryId = fiction.CategoryId, ImageUrl = "/img/alchemist.jpg" },
                    new Product { Name = "Clean Code", Description = "A Handbook of Agile Software Craftsmanship.", Price = 699, StockQuantity = 30, CategoryId = tech.CategoryId, ImageUrl = "/img/cleancode.jpg" },
                    new Product { Name = "Brief History of Time", Description = "By Stephen Hawking.", Price = 399, StockQuantity = 20, CategoryId = sci.CategoryId, ImageUrl = "/img/briefhistory.jpg" }
                );
            }

            await db.SaveChangesAsync();
        }
    }
}
