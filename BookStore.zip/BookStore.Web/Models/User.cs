using System.ComponentModel.DataAnnotations;

namespace BookStore.Web.Models
{
    public enum UserRole { CUSTOMER, ADMIN }

    public class User
    {
        [Key]
        public int UserId { get; set; }

        [Required, MaxLength(50)]
        public string Username { get; set; } = string.Empty;

        [Required, MaxLength(255)]
        public string PasswordHash { get; set; } = string.Empty;

        [Required, EmailAddress, MaxLength(100)]
        public string Email { get; set; } = string.Empty;

        [Required]
        public UserRole Role { get; set; } = UserRole.CUSTOMER;

        public ICollection<Order>? Orders { get; set; }
    }
}
