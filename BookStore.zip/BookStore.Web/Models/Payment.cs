using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookStore.Web.Models
{
    public enum PaymentStatus { PENDING, COMPLETED, FAILED }

    public class Payment
    {
        [Key]
        public int PaymentId { get; set; }

        public int OrderId { get; set; }
        public Order? Order { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        public decimal Amount { get; set; }

        public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.PENDING;

        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;
    }
}
