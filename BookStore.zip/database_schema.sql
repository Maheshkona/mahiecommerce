-- SQL Server schema for BookStore
CREATE TABLE [Users] (
  [UserId] INT IDENTITY(1,1) PRIMARY KEY,
  [Username] VARCHAR(50) NOT NULL UNIQUE,
  [PasswordHash] VARCHAR(255) NOT NULL,
  [Email] VARCHAR(100) NOT NULL,
  [Role] VARCHAR(20) NOT NULL CHECK ([Role] IN ('CUSTOMER','ADMIN'))
);

CREATE TABLE [Category] (
  [CategoryId] INT IDENTITY(1,1) PRIMARY KEY,
  [Name] VARCHAR(100) NOT NULL
);

CREATE TABLE [Product] (
  [ProductId] INT IDENTITY(1,1) PRIMARY KEY,
  [Name] VARCHAR(100) NOT NULL,
  [Description] TEXT NULL,
  [Price] DECIMAL(10,2) NOT NULL,
  [CategoryId] INT NOT NULL,
  [StockQuantity] INT NOT NULL DEFAULT 0,
  [ImageUrl] VARCHAR(512) NULL,
  CONSTRAINT FK_Product_Category FOREIGN KEY ([CategoryId]) REFERENCES [Category]([CategoryId])
);

CREATE TABLE [CartItem] (
  [CartItemId] INT IDENTITY(1,1) PRIMARY KEY,
  [UserId] INT NOT NULL,
  [ProductId] INT NOT NULL,
  [Quantity] INT NOT NULL DEFAULT 1,
  CONSTRAINT FK_CartItem_User FOREIGN KEY ([UserId]) REFERENCES [Users]([UserId]),
  CONSTRAINT FK_CartItem_Product FOREIGN KEY ([ProductId]) REFERENCES [Product]([ProductId])
);

CREATE TABLE [Order] (
  [OrderId] INT IDENTITY(1,1) PRIMARY KEY,
  [UserId] INT NOT NULL,
  [TotalAmount] DECIMAL(10,2) NOT NULL,
  [OrderDate] DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
  [Status] VARCHAR(20) NOT NULL CHECK ([Status] IN ('PENDING','SHIPPED','DELIVERED','CANCELLED')),
  CONSTRAINT FK_Order_User FOREIGN KEY ([UserId]) REFERENCES [Users]([UserId])
);

CREATE TABLE [OrderItem] (
  [OrderItemId] INT IDENTITY(1,1) PRIMARY KEY,
  [OrderId] INT NOT NULL,
  [ProductId] INT NOT NULL,
  [Quantity] INT NOT NULL,
  [UnitPrice] DECIMAL(10,2) NOT NULL,
  CONSTRAINT FK_OrderItem_Order FOREIGN KEY ([OrderId]) REFERENCES [Order]([OrderId]),
  CONSTRAINT FK_OrderItem_Product FOREIGN KEY ([ProductId]) REFERENCES [Product]([ProductId])
);

CREATE TABLE [Payment] (
  [PaymentId] INT IDENTITY(1,1) PRIMARY KEY,
  [OrderId] INT NOT NULL,
  [Amount] DECIMAL(10,2) NOT NULL,
  [PaymentStatus] VARCHAR(20) NOT NULL CHECK ([PaymentStatus] IN ('PENDING','COMPLETED','FAILED')),
  [PaymentDate] DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
  CONSTRAINT FK_Payment_Order FOREIGN KEY ([OrderId]) REFERENCES [Order]([OrderId])
);

-- Seed data
INSERT INTO [Category]([Name]) VALUES ('Fiction'),('Technology'),('Science');

INSERT INTO [Product]([Name],[Description],[Price],[CategoryId],[StockQuantity],[ImageUrl]) VALUES
('The Alchemist','A novel by Paulo Coelho.',299,1,50,'/img/alchemist.jpg'),
('Clean Code','A Handbook of Agile Software Craftsmanship.',699,2,30,'/img/cleancode.jpg'),
('Brief History of Time','By Stephen Hawking.',399,3,20,'/img/briefhistory.jpg');

-- Admin user with plain placeholder password (replace with hashed if needed)
-- For demo, application seeds with a hashed Admin@123 automatically, so this is optional.
