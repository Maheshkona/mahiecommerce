using Microsoft.AspNetCore.Mvc;

namespace BookStore.Areas.Admin.Controllers
{
    /// <summary>
    /// Administration of customers.  Displays registered users and
    /// allows administrators to view basic customer information.
    /// </summary>
    [Area("Admin")]
    public class CustomersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}