namespace BookStore.Models
{
    /// <summary>
    /// Represents a shipping or billing address for a customer.  A
    /// customer can maintain multiple addresses (home, office, etc.).
    /// </summary>
    public class Address
    {
        public int AddressId { get; set; }
        public int CustomerId { get; set; }
        public Customer? Customer { get; set; }
        public string Street { get; set; } = string.Empty;
        public string City { get; set; } = string.Empty;
        public string State { get; set; } = string.Empty;
        public string PostalCode { get; set; } = string.Empty;
        public string Country { get; set; } = string.Empty;
    }
}