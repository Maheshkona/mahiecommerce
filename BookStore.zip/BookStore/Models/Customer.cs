using System;
using System.Collections.Generic;

namespace BookStore.Models
{
    /// <summary>
    /// Represents a customer (end user) of the book store.  The
    /// PasswordHash should contain a hashed password and not be stored
    /// plain text.  Each customer can have multiple shipping addresses,
    /// a cart and a wishlist.  Orders and payments are associated
    /// through navigation properties.
    /// </summary>
    public class Customer
    {
        public int CustomerId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string? Phone { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public ICollection<Address> Addresses { get; set; } = new List<Address>();
        public ICollection<Order> Orders { get; set; } = new List<Order>();

        public Wishlist? Wishlist { get; set; }
        public Cart? Cart { get; set; }
    }
}