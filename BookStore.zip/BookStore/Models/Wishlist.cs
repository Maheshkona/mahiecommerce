using System.Collections.Generic;

namespace BookStore.Models
{
    /// <summary>
    /// Represents a customer's wishlist.  A wishlist is a one‑to‑one
    /// relationship with the customer and contains multiple wishlist
    /// items.  It allows customers to save books for later without
    /// purchasing them immediately.
    /// </summary>
    public class Wishlist
    {
        public int WishlistId { get; set; }
        public int CustomerId { get; set; }
        public Customer? Customer { get; set; }
        public ICollection<WishlistItem> WishlistItems { get; set; } = new List<WishlistItem>();
    }
}