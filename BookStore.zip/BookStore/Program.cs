using BookStore.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Register MVC controllers with views and the Entity Framework Core
// DbContext.  The connection string lives in appsettings.json and can
// easily be changed to point at a real SQL Server instance.  When
// working with the database‑first approach you would scaffold your
// models and context from the existing database.
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

// Configure the HTTP request pipeline.  In production we use the
// exception handler and enable HSTS.  Static files must be served
// before routing so that CSS/JS/images are found under wwwroot.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

// When using Areas for the admin portion of the site this route
// definition must come before the default route.  It matches URLs
// beginning with a valid area name and dispatches to the correct
// controller/action inside that area.  For example:
//   /Admin/Dashboard
// will map to Areas/Admin/Controllers/DashboardController.Index().
app.MapControllerRoute(
    name: "areas",
    pattern: "{area:exists}/{controller=Dashboard}/{action=Index}/{id?}");

// The default route for the public portion of the site.  If you
// navigate to /Home/Index the Home controller's Index action will
// render the homepage.  Omitting the controller/action defaults to
// Home/Index.
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();