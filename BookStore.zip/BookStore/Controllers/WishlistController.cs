using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    /// <summary>
    /// Displays the customer's wishlist.  Items are stored in local
    /// storage in this demo.  A server‑side implementation would
    /// require actions to add and remove books from the wishlist.
    /// </summary>
    public class WishlistController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}