using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    /// <summary>
    /// Displays the catalog of available books.  In a real
    /// application you would query the database and optionally
    /// accept search or filter parameters.
    /// </summary>
    public class ShopController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}