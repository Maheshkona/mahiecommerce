using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    /// <summary>
    /// Handles the shopping cart page.  Cart interactions (adding,
    /// updating quantities and removing items) happen client side via
    /// JavaScript in this example.  In a production system you would
    /// persist the cart on the server and perform updates through
    /// controller actions and API endpoints.
    /// </summary>
    public class CartController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}