using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    /// <summary>
    /// Manages user authentication and profile pages.  The demo
    /// implementation stores user details in localStorage on the
    /// client.  In a real project you would use ASP.NET Core Identity
    /// for secure registration and login.
    /// </summary>
    public class AccountController : Controller
    {
        public IActionResult Register()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Profile()
        {
            return View();
        }

        public IActionResult AddAddress()
        {
            return View();
        }
    }
}