using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    /// <summary>
    /// Handles the payment workflow.  Index shows the payment form
    /// while Success displays confirmation once the mock payment is
    /// complete.
    /// </summary>
    public class PaymentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Success()
        {
            return View();
        }
    }
}