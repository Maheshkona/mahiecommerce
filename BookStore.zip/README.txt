# BookStore (ASP.NET Core 8 MVC + EF Core)

Mini e-commerce for books with user & admin sides.

## Quick Start (SQL Server LocalDB)
1. Open `BookStore.Web/BookStore.Web.csproj` in Visual Studio 2022.
2. Ensure SQL Server LocalDB is installed (default with VS).
3. Update `appsettings.json` connection string if needed.
4. Build & Run.
   - On first run, DB is created (`EnsureCreated`) and seeded with:
     - Admin: **admin / Admin@123**
     - Customer: **john / John@123**
5. Login:
   - Admin: go to `/Admin/Dashboard` after login as admin.
   - Customer: add to cart, checkout, view orders.

## Database-First (SSMS)
- Use `database_schema.sql` to create tables.
- Update connection string to your SQL Server instance.
- Remove `EnsureCreated()` if you want to manage schema manually.

## Features
- Products: browse, details, admin CRUD
- Cart: add/remove, checkout
- Orders: create, status update (admin), my orders (user)
- Payments: mock success
- Auth: cookie-based with roles (ADMIN/CUSTOMER), password hashing via Identity hasher

