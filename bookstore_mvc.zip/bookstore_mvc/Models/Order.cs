using System.ComponentModel.DataAnnotations;

namespace BookStoreMVC.Models
{
    public enum OrderStatus
    {
        PENDING,
        SHIPPED,
        DELIVERED,
        CANCELLED
    }

    public class Order
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int UserId { get; set; }

        public User? User { get; set; }

        [Required]
        public decimal TotalAmount { get; set; }

        [Required]
        public DateTime OrderDate { get; set; }

        [Required]
        public OrderStatus Status { get; set; } = OrderStatus.PENDING;

        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
        public Payment? Payment { get; set; }
    }
}