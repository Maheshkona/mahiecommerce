using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommercePlatform.Models
{
    /// <summary>
    /// Represents a product in the online store.  The naming of the
    /// properties aligns with the database schema provided in the low level
    /// design document.  Data annotations are used to map to the
    /// corresponding table and columns.
    /// </summary>
    public class Product
    {
        [Key]
        [Column("productid")]
        public int ProductId { get; set; }

        [Required]
        [Column("name")]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Column("description")]
        public string? Description { get; set; }

        [Column("price", TypeName = "DECIMAL(10,2)")]
        public decimal Price { get; set; }

        [Column("categoryid")]
        public int CategoryId { get; set; }

        public Category? Category { get; set; }

        [Column("stockQuantity")]
        public int StockQuantity { get; set; }
    }
}