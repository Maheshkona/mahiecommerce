using ECommercePlatform.Data;
using ECommercePlatform.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommercePlatform.Controllers
{
    /// <summary>
    /// Manages the customer shopping cart.  Users must be authenticated
    /// in order to access their cart.  Items are identified by the
    /// combination of user and product IDs.
    /// </summary>
    [Authorize]
    public class CartController : Controller
    {
        private readonly AppDbContext _context;

        public CartController(AppDbContext context)
        {
            _context = context;
        }

        // GET: /Cart
        public async Task<IActionResult> Index()
        {
            var userId = int.Parse(User.Claims.First(c => c.Type == "UserId").Value);
            var cartItems = await _context.Carts
                .Where(c => c.UserId == userId)
                .Include(c => c.Product)
                .ToListAsync();
            return View(cartItems);
        }

        // POST: /Cart/Add
        [HttpPost]
        public async Task<IActionResult> Add(int productId, int quantity = 1)
        {
            var userId = int.Parse(User.Claims.First(c => c.Type == "UserId").Value);
            var existing = await _context.Carts
                .FirstOrDefaultAsync(c => c.ProductId == productId && c.UserId == userId);
            if (existing != null)
            {
                existing.Quantity += quantity;
                _context.Update(existing);
            }
            else
            {
                var cart = new Cart
                {
                    ProductId = productId,
                    Quantity = quantity,
                    UserId = userId
                };
                _context.Carts.Add(cart);
            }
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        // GET: /Cart/Remove/5
        public async Task<IActionResult> Remove(int id)
        {
            var cartItem = await _context.Carts.FindAsync(id);
            if (cartItem != null)
            {
                _context.Carts.Remove(cartItem);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Index");
        }
    }
}