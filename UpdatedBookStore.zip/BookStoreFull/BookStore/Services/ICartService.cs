using System.Threading.Tasks;
using BookStore.Models;

namespace BookStore.Services
{
    /// <summary>
    /// Defines operations related to a user's shopping cart.
    /// </summary>
    public interface ICartService
    {
        Task<Cart> GetCartAsync(int userId);
        Task AddItemAsync(int userId, int bookId, int quantity);
        Task RemoveItemAsync(int cartItemId);
        Task ClearCartAsync(int userId);
    }
}