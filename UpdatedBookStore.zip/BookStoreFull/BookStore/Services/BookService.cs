using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookStore.Data;
using BookStore.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Services
{
    /// <summary>
    /// Concrete implementation of <see cref="IBookService"/> that
    /// uses Entity Framework Core to perform CRUD operations on
    /// books.  In a real application you would add validation and
    /// business rules here.
    /// </summary>
    public class BookService : IBookService
    {
        private readonly AppDbContext _context;
        public BookService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<Book> AddBookAsync(Book book)
        {
            _context.Books.Add(book);
            await _context.SaveChangesAsync();
            return book;
        }
        public async Task<Book?> GetBookByIdAsync(int id)
        {
            return await _context.Books
                .Include(b => b.Category)
                .Include(b => b.CartItems)
                .Include(b => b.WishlistItems)
                .Include(b => b.OrderItems)
                .FirstOrDefaultAsync(b => b.BookId == id);
        }
        public async Task<IEnumerable<Book>> GetAllBooksAsync()
        {
            return await _context.Books
                .AsNoTracking()
                .Include(b => b.Category)
                .ToListAsync();
        }
        public async Task<Book?> UpdateBookAsync(int id, Book updated)
        {
            var existing = await _context.Books.FindAsync(id);
            if (existing == null)
            {
                return null;
            }
            existing.Title = updated.Title;
            existing.Author = updated.Author;
            existing.Description = updated.Description;
            existing.Price = updated.Price;
            existing.CategoryId = updated.CategoryId;
            existing.ImageUrl = updated.ImageUrl;
            existing.StockQuantity = updated.StockQuantity;
            await _context.SaveChangesAsync();
            return existing;
        }
        public async Task<bool> DeleteBookAsync(int id)
        {
            var existing = await _context.Books.FindAsync(id);
            if (existing == null)
            {
                return false;
            }
            _context.Books.Remove(existing);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}