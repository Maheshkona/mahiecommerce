using System.Collections.Generic;
using System.Threading.Tasks;
using BookStore.Models;

namespace BookStore.Services
{
    /// <summary>
    /// Defines operations for managing orders.
    /// </summary>
    public interface IOrderService
    {
        Task<Order> CreateOrderAsync(int customerId);
        Task<Order?> GetOrderByIdAsync(int orderId);
        Task<IEnumerable<Order>> ListOrdersAsync(int? customerId = null);
        Task<bool> UpdateStatusAsync(int orderId, string status);
    }
}