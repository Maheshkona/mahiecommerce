using Microsoft.AspNetCore.Mvc;

namespace BookStore.Areas.Admin.Controllers
{
    /// <summary>
    /// Administration of the product catalog.  The Manage action
    /// renders a page where books can be added, edited or deleted.
    /// </summary>
    [Area("Admin")]
    public class ProductsController : Controller
    {
        public IActionResult Manage()
        {
            if (!Request.Cookies.TryGetValue("Role", out var role) || role != "ADMIN")
            {
                return RedirectToAction("Login", "Account", new { area = "" });
            }
            return View();
        }
    }
}