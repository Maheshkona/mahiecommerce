using Microsoft.AspNetCore.Mvc;

namespace BookStore.Areas.Admin.Controllers
{
    /// <summary>
    /// Administration of customers.  Displays registered users and
    /// allows administrators to view basic customer information.
    /// </summary>
    [Area("Admin")]
    public class CustomersController : Controller
    {
        public IActionResult Index()
        {
            // Only allow admins
            if (!Request.Cookies.TryGetValue("Role", out var role) || role != "ADMIN")
            {
                return RedirectToAction("Login", "Account", new { area = "" });
            }
            return View();
        }
    }
}