using Microsoft.AspNetCore.Mvc;

namespace BookStore.Areas.Admin.Controllers
{
    /// <summary>
    /// Displays and allows editing of the administrator's profile.
    /// </summary>
    [Area("Admin")]
    public class ProfileController : Controller
    {
        public IActionResult Index()
        {
            if (!Request.Cookies.TryGetValue("Role", out var role) || role != "ADMIN")
            {
                return RedirectToAction("Login", "Account", new { area = "" });
            }
            return View();
        }
    }
}