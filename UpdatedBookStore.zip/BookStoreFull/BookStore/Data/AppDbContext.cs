using BookStore.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Data
{
    /// <summary>
    /// The Entity Framework Core DbContext used by the application.
    /// Each DbSet maps to a table in the database.  Customization of
    /// relationships happens in OnModelCreating.  The database‑first
    /// workflow scaffolds this class from an existing database, but
    /// defining it manually allows for code‑first migrations.
    /// </summary>
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<Book> Books { get; set; } = default!;
        public DbSet<Category> Categories { get; set; } = default!;
        public DbSet<Customer> Customers { get; set; } = default!;
        public DbSet<Address> Addresses { get; set; } = default!;
        public DbSet<Order> Orders { get; set; } = default!;
        public DbSet<OrderItem> OrderItems { get; set; } = default!;
        public DbSet<Wishlist> Wishlists { get; set; } = default!;
        public DbSet<WishlistItem> WishlistItems { get; set; } = default!;
        public DbSet<Cart> Carts { get; set; } = default!;
        public DbSet<CartItem> CartItems { get; set; } = default!;
        public DbSet<Payment> Payments { get; set; } = default!;
        public DbSet<AdminUser> AdminUsers { get; set; } = default!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure OrderItem relationships
            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.Order)
                .WithMany(o => o.OrderItems)
                .HasForeignKey(oi => oi.OrderId);
            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.Book)
                .WithMany(b => b.OrderItems)
                .HasForeignKey(oi => oi.BookId);

            // Configure CartItem relationships
            modelBuilder.Entity<CartItem>()
                .HasOne(ci => ci.Cart)
                .WithMany(c => c.CartItems)
                .HasForeignKey(ci => ci.CartId);
            modelBuilder.Entity<CartItem>()
                .HasOne(ci => ci.Book)
                .WithMany(b => b.CartItems)
                .HasForeignKey(ci => ci.BookId);

            // Configure WishlistItem relationships
            modelBuilder.Entity<WishlistItem>()
                .HasOne(wi => wi.Wishlist)
                .WithMany(w => w.WishlistItems)
                .HasForeignKey(wi => wi.WishlistId);
            modelBuilder.Entity<WishlistItem>()
                .HasOne(wi => wi.Book)
                .WithMany(b => b.WishlistItems)
                .HasForeignKey(wi => wi.BookId);

            // One‑to‑one relationships
            modelBuilder.Entity<Wishlist>()
                .HasOne(w => w.Customer)
                .WithOne(c => c.Wishlist)
                .HasForeignKey<Wishlist>(w => w.CustomerId);
            modelBuilder.Entity<Cart>()
                .HasOne(ca => ca.Customer)
                .WithOne(cu => cu.Cart)
                .HasForeignKey<Cart>(ca => ca.CustomerId);
            modelBuilder.Entity<Payment>()
                .HasOne(p => p.Order)
                .WithOne(o => o.Payment)
                .HasForeignKey<Payment>(p => p.OrderId);
        }
    }
}