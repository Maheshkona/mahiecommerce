using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace BookStore.Controllers
{
    /// <summary>
    /// Displays the logged in customer's past orders.  Orders are
    /// stored client side in the demo; in a production system you
    /// would query the database and show real order history.
    /// </summary>
    public class OrdersController : Controller
    {
        private readonly BookStore.Services.IOrderService _orderService;
        public OrdersController(BookStore.Services.IOrderService orderService)
        {
            _orderService = orderService;
        }
        public async Task<IActionResult> Index()
        {
            if (!Request.Cookies.TryGetValue("UserId", out var uid) || !int.TryParse(uid, out var userId))
            {
                return RedirectToAction("Login", "Account");
            }
            var orders = await _orderService.ListOrdersAsync(userId);
            return View(orders);
        }

        [HttpGet]
        public async Task<IActionResult> CreateOrder()
        {
            if (!Request.Cookies.TryGetValue("UserId", out var uid) || !int.TryParse(uid, out var userId))
            {
                return RedirectToAction("Login", "Account");
            }
            try
            {
                var order = await _orderService.CreateOrderAsync(userId);
                // redirect to payment
                return RedirectToAction("Index", "Payment", new { orderId = order.OrderId });
            }
            catch (Exception ex)
            {
                // handle error: maybe cart empty
                TempData["Error"] = ex.Message;
                return RedirectToAction("Index", "Cart");
            }
        }
    }
}