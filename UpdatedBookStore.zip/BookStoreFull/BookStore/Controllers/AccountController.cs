using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    /// <summary>
    /// Manages user authentication and profile pages.  The demo
    /// implementation stores user details in localStorage on the
    /// client.  In a real project you would use ASP.NET Core Identity
    /// for secure registration and login.
    /// </summary>
    public class AccountController : Controller
    {
        private readonly BookStore.Services.IUserService _userService;
        public AccountController(BookStore.Services.IUserService userService)
        {
            _userService = userService;
        }
        public IActionResult Register()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Profile()
        {
            return View();
        }

        public IActionResult AddAddress()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(BookStore.Models.Customer model, string password)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            model.PasswordHash = password;
            try
            {
                await _userService.RegisterAsync(model);
                // set auth cookie
                Response.Cookies.Append("UserId", model.CustomerId.ToString());
                Response.Cookies.Append("Role", model.Role);
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(model);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string emailOrUsername, string password)
        {
            var user = await _userService.LoginAsync(emailOrUsername, password);
            if (user == null)
            {
                ModelState.AddModelError("", "Invalid credentials");
                return View();
            }
            // set auth cookie
            Response.Cookies.Append("UserId", user.CustomerId.ToString());
            Response.Cookies.Append("Role", user.Role);
            if (user.Role == "ADMIN")
            {
                return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
            }
            return RedirectToAction("Index", "Home");
        }

        public IActionResult Logout()
        {
            Response.Cookies.Delete("UserId");
            Response.Cookies.Delete("Role");
            return RedirectToAction("Login");
        }
    }
}