using System;
using System.Collections.Generic;

namespace BookStore.Models
{
    /// <summary>
    /// Represents a customer's order.  An order contains one or more
    /// order items and optionally a payment.  The Status field can
    /// capture states such as Pending, Processing, Shipped or
    /// Delivered.
    /// </summary>
    public class Order
    {
        public int OrderId { get; set; }
        public int CustomerId { get; set; }
        public Customer? Customer { get; set; }
        public DateTime OrderDate { get; set; } = DateTime.UtcNow;
        public string Status { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }

        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
        public Payment? Payment { get; set; }
    }
}