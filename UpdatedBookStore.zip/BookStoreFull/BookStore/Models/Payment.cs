using System;

namespace BookStore.Models
{
    /// <summary>
    /// Represents payment information for an order.  In a real
    /// application sensitive details such as credit card numbers are
    /// tokenised and stored securely through a payment gateway.  This
    /// class stores minimal information for demonstration purposes.
    /// </summary>
    public class Payment
    {
        public int PaymentId { get; set; }
        public int OrderId { get; set; }
        public Order? Order { get; set; }
        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;
        public string PaymentMethod { get; set; } = string.Empty;
        public string PaymentStatus { get; set; } = string.Empty;
        public decimal Amount { get; set; }
    }
}