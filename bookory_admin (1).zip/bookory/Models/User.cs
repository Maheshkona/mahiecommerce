using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace Bookory.Models
{
    /// <summary>
    /// Represents an application user. Inherits from IdentityUser to leverage
    /// built‑in ASP.NET Core Identity support for authentication and authorization.
    /// Additional profile fields are defined here for the e‑commerce platform.
    /// </summary>
    public class User : IdentityUser
    {
        [StringLength(100)]
        public string? FirstName { get; set; }

        [StringLength(100)]
        public string? LastName { get; set; }

        // Role is managed by Identity; additional roles can be assigned via RoleManager.

        /// <summary>
        /// Navigation property for the addresses associated with the user.
        /// A user can have multiple shipping addresses.
        /// </summary>
        public ICollection<Address> Addresses { get; set; } = new List<Address>();

        /// <summary>
        /// Navigation property for the shopping cart items associated with the user.
        /// </summary>
        public ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();

        /// <summary>
        /// Navigation property for the wishlist items associated with the user.
        /// </summary>
        public ICollection<Wishlist> Wishlists { get; set; } = new List<Wishlist>();

        /// <summary>
        /// Navigation property for orders placed by the user.
        /// </summary>
        public ICollection<Order> Orders { get; set; } = new List<Order>();
    }
}