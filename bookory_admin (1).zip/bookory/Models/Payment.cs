using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Bookory.Models
{
    /// <summary>
    /// Represents a payment made for an order. Stores payment method and transaction details.
    /// </summary>
    public class Payment
    {
        [Key]
        public int PaymentId { get; set; }

        [Required]
        public int OrderId { get; set; }

        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;

        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }

        /// <summary>
        /// e.g. CreditCard, DebitCard, UPI, NetBanking etc.
        /// </summary>
        [MaxLength(50)]
        public string PaymentMethod { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? TransactionId { get; set; }

        [MaxLength(50)]
        public string Status { get; set; } = "Pending";

        [ForeignKey(nameof(OrderId))]
        public Order? Order { get; set; }
    }
}