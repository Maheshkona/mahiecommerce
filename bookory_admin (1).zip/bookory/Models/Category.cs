using System.ComponentModel.DataAnnotations;

namespace Bookory.Models
{
    /// <summary>
    /// Represents a product category. Each product belongs to one category.
    /// </summary>
    public class Category
    {
        [Key]
        public int CategoryId { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(1000)]
        public string? Description { get; set; }

        /// <summary>
        /// Collection of products associated with this category.
        /// </summary>
        public ICollection<Product> Products { get; set; } = new List<Product>();
    }
}