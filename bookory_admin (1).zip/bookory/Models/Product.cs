using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Bookory.Models
{
    /// <summary>
    /// Represents a product available for purchase. Each product belongs to a category.
    /// </summary>
    public class Product
    {
        [Key]
        public int ProductId { get; set; }

        [Required]
        [MaxLength(200)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(4000)]
        public string? Description { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        /// <summary>
        /// The URL or relative path of the product's image.
        /// </summary>
        [MaxLength(500)]
        public string? ImageUrl { get; set; }

        /// <summary>
        /// Current inventory level for the product.
        /// </summary>
        public int Stock { get; set; }

        // Foreign key referencing the category
        [Required]
        public int CategoryId { get; set; }

        [ForeignKey(nameof(CategoryId))]
        public Category? Category { get; set; }

        // Navigation property for order items referencing this product
        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

        // Navigation property for cart items referencing this product
        public ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();

        // Navigation property for wishlist entries referencing this product
        public ICollection<Wishlist> Wishlists { get; set; } = new List<Wishlist>();
    }
}