using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Bookory.Models
{
    /// <summary>
    /// Represents a customer's order. Contains basic order information and
    /// references to order items, payment details and shipping address.
    /// </summary>
    public class Order
    {
        [Key]
        public int OrderId { get; set; }

        [Required]
        public string UserId { get; set; } = string.Empty;

        /// <summary>
        /// Date and time when the order was placed.
        /// </summary>
        public DateTime OrderDate { get; set; } = DateTime.UtcNow;

        /// <summary>
        /// Total cost for the order. Populated when the order is placed.
        /// </summary>
        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; }

        /// <summary>
        /// Current status of the order (e.g., Pending, Paid, Shipped, Delivered, Cancelled).
        /// </summary>
        [MaxLength(50)]
        public string Status { get; set; } = "Pending";

        /// <summary>
        /// Foreign key referencing the shipping address used for this order.
        /// </summary>
        public int? AddressId { get; set; }

        [ForeignKey(nameof(AddressId))]
        public Address? ShippingAddress { get; set; }

        /// <summary>
        /// Navigation property for the items in this order.
        /// </summary>
        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

        /// <summary>
        /// Navigation property for the payment associated with this order.
        /// </summary>
        public Payment? Payment { get; set; }

        [ForeignKey(nameof(UserId))]
        public User? User { get; set; }
    }
}