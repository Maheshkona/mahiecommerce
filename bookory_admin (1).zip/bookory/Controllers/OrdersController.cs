using Bookory.Models;
using Bookory.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Bookory.Controllers
{
    /// <summary>
    /// Handles creation and viewing of orders for authenticated users.
    /// </summary>
    [Authorize]
    public class OrdersController : Controller
    {
        private readonly IOrderService _orderService;
        private readonly IUserService _userService;
        private readonly Bookory.Data.BookoryContext _context;

        public OrdersController(IOrderService orderService, IUserService userService, Bookory.Data.BookoryContext context)
        {
            _orderService = orderService;
            _userService = userService;
            _context = context;
        }

        // GET: /Orders
        // Lists orders for the current user
        public async Task<IActionResult> Index()
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }
            var orders = await _orderService.GetOrdersByUserAsync(userId);
            return View(orders);
        }

        // GET: /Orders/Checkout
        // Displays a page to select a shipping address and payment method
        public async Task<IActionResult> Checkout()
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }
            var user = await _userService.GetByIdAsync(userId);
            if (user == null)
            {
                return NotFound();
            }
            // Provide addresses to the view for selection
            ViewBag.Addresses = user.Addresses;
            return View();
        }

        // POST: /Orders/PlaceOrder
        [HttpPost]
        public async Task<IActionResult> PlaceOrder(int addressId, string paymentMethod)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (userId == null)
            {
                return Unauthorized();
            }
            var order = await _orderService.CreateOrderAsync(userId, addressId, paymentMethod);
            return RedirectToAction("Details", new { id = order.OrderId });
        }

        // GET: /Orders/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var order = await _orderService.GetOrderByIdAsync(id);
            if (order == null)
            {
                return NotFound();
            }
            return View(order);
        }
    }
}