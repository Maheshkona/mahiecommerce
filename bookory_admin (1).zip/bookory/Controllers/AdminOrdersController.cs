using Bookory.Models;
using Bookory.Services;
using Bookory.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Bookory.Controllers
{
    /// <summary>
    /// Provides order management for administrators.
    /// </summary>
    [Authorize(Roles = "Admin")]
    public class AdminOrdersController : Controller
    {
        private readonly IOrderService _orderService;
        private readonly Bookory.Data.BookoryContext _context;

        public AdminOrdersController(IOrderService orderService, Bookory.Data.BookoryContext context)
        {
            _orderService = orderService;
            _context = context;
        }

        // GET: /AdminOrders
        public async Task<IActionResult> Index()
        {
            // Admin sees all orders for all users
            var orders = await _orderService.GetAllOrdersAsync();
            return View(orders);
        }

        // GET: /AdminOrders/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var order = await _orderService.GetOrderByIdAsync(id);
            if (order == null)
            {
                return NotFound();
            }
            return View(order);
        }

        // POST: /AdminOrders/UpdateStatus/5
        [HttpPost]
        public async Task<IActionResult> UpdateStatus(int id, string status)
        {
            var order = await _orderService.GetOrderByIdAsync(id);
            if (order == null)
            {
                return NotFound();
            }
            order.Status = status;
            _context.Orders.Update(order);
            await _context.SaveChangesAsync();
            return RedirectToAction("Details", new { id });
        }
    }
}