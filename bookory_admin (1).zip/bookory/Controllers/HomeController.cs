using Bookory.Services;
using Microsoft.AspNetCore.Mvc;

namespace Bookory.Controllers
{
    /// <summary>
    /// Handles public pages such as the home page.
    /// </summary>
    public class HomeController : Controller
    {
        private readonly IProductService _productService;

        public HomeController(IProductService productService)
        {
            _productService = productService;
        }

        // Displays the landing page with a few bestselling books.
        public async Task<IActionResult> Index()
        {
            var products = await _productService.GetAllAsync();
            // For demonstration, simply take the first 6 items as "bestsellers".
            var bestsellers = products.Take(6);
            return View(bestsellers);
        }
    }
}