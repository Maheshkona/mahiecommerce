using Bookory.Data;
using Bookory.Models;
using Microsoft.EntityFrameworkCore;

namespace Bookory.Services
{
    /// <summary>
    /// Implements order management operations. Creates orders from the user's cart,
    /// calculates totals, persists the order and associated items, and records payment.
    /// </summary>
    public class OrderService : IOrderService
    {
        private readonly BookoryContext _context;
        private readonly ICartService _cartService;

        public OrderService(BookoryContext context, ICartService cartService)
        {
            _context = context;
            _cartService = cartService;
        }

        public async Task<Order> CreateOrderAsync(string userId, int addressId, string paymentMethod)
        {
            // Retrieve cart items for the user
            var cartItems = await _cartService.GetCartItemsAsync(userId);
            if (!cartItems.Any())
            {
                throw new InvalidOperationException("Cannot create an order with an empty cart.");
            }

            // Calculate total amount
            decimal total = cartItems.Sum(ci => ci.Product?.Price * ci.Quantity ?? 0);

            // Create order entity
            var order = new Order
            {
                UserId = userId,
                AddressId = addressId,
                OrderDate = DateTime.UtcNow,
                Status = "Pending",
                TotalAmount = total
            };
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            // Create order items
            foreach (var item in cartItems)
            {
                var orderItem = new OrderItem
                {
                    OrderId = order.OrderId,
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    UnitPrice = item.Product?.Price ?? 0
                };
                _context.OrderItems.Add(orderItem);
            }
            await _context.SaveChangesAsync();

            // Create payment record
            var payment = new Payment
            {
                OrderId = order.OrderId,
                Amount = total,
                PaymentMethod = paymentMethod,
                Status = "Initiated"
            };
            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();

            // Update order with payment reference
            order.Payment = payment;
            order.Status = "Paid";
            _context.Orders.Update(order);
            await _context.SaveChangesAsync();

            // Reduce stock
            foreach (var item in cartItems)
            {
                if (item.Product != null)
                {
                    item.Product.Stock -= item.Quantity;
                    _context.Products.Update(item.Product);
                }
            }
            await _context.SaveChangesAsync();

            // Clear cart
            await _cartService.ClearCartAsync(userId);

            return order;
        }

        public async Task<IEnumerable<Order>> GetOrdersByUserAsync(string userId)
        {
            return await _context.Orders
                .Where(o => o.UserId == userId)
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product)
                .Include(o => o.Payment)
                .Include(o => o.ShippingAddress)
                .ToListAsync();
        }

        public async Task<Order?> GetOrderByIdAsync(int orderId)
        {
            return await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product)
                .Include(o => o.Payment)
                .Include(o => o.ShippingAddress)
                .FirstOrDefaultAsync(o => o.OrderId == orderId);
        }

        public async Task<IEnumerable<Order>> GetAllOrdersAsync()
        {
            return await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product)
                .Include(o => o.Payment)
                .Include(o => o.ShippingAddress)
                .Include(o => o.User)
                .ToListAsync();
        }
    }
}