using Bookory.Models;

namespace Bookory.Services
{
    /// <summary>
    /// Provides operations to place and manage orders.
    /// </summary>
    public interface IOrderService
    {
        Task<Order> CreateOrderAsync(string userId, int addressId, string paymentMethod);
        Task<IEnumerable<Order>> GetOrdersByUserAsync(string userId);
        Task<Order?> GetOrderByIdAsync(int orderId);

        /// <summary>
        /// Retrieves all orders in the system. Intended for administrators.
        /// </summary>
        Task<IEnumerable<Order>> GetAllOrdersAsync();
    }
}