using Bookory.Models;

namespace Bookory.Services
{
    /// <summary>
    /// Provides operations for managing user wishlists.
    /// </summary>
    public interface IWishlistService
    {
        Task<IEnumerable<Wishlist>> GetWishlistAsync(string userId);
        Task AddAsync(string userId, int productId);
        Task RemoveAsync(int wishlistId);
    }
}