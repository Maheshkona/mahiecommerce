using Bookory.Models;

namespace Bookory.Services
{
    /// <summary>
    /// Provides operations for user management. Wraps the Identity API for ease of use.
    /// </summary>
    public interface IUserService
    {
        Task<User?> GetByIdAsync(string userId);
        Task<IEnumerable<User>> GetAllAsync();
    }
}