using Bookory.Models;

namespace Bookory.Services
{
    /// <summary>
    /// Provides operations for managing the user's shopping cart.
    /// </summary>
    public interface ICartService
    {
        Task<IEnumerable<CartItem>> GetCartItemsAsync(string userId);
        Task AddItemAsync(string userId, int productId, int quantity);
        Task UpdateQuantityAsync(int cartItemId, int quantity);
        Task RemoveItemAsync(int cartItemId);
        Task ClearCartAsync(string userId);
    }
}