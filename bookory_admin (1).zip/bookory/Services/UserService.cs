using Bookory.Models;
using Microsoft.AspNetCore.Identity;

namespace Bookory.Services
{
    /// <summary>
    /// Implements user-related operations by delegating to ASP.NET Core Identity's UserManager.
    /// </summary>
    public class UserService : IUserService
    {
        private readonly UserManager<User> _userManager;

        public UserService(UserManager<User> userManager)
        {
            _userManager = userManager;
        }

        public async Task<User?> GetByIdAsync(string userId)
        {
            return await _userManager.FindByIdAsync(userId);
        }

        public async Task<IEnumerable<User>> GetAllAsync()
        {
            return await Task.FromResult(_userManager.Users.AsEnumerable());
        }
    }
}