using Bookory.Data;
using Bookory.Models;
using Microsoft.EntityFrameworkCore;

namespace Bookory.Services
{
    /// <summary>
    /// Implements wishlist operations using the database context.
    /// </summary>
    public class WishlistService : IWishlistService
    {
        private readonly BookoryContext _context;

        public WishlistService(BookoryContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Wishlist>> GetWishlistAsync(string userId)
        {
            return await _context.Wishlists
                .Where(w => w.UserId == userId)
                .Include(w => w.Product)
                .ToListAsync();
        }

        public async Task AddAsync(string userId, int productId)
        {
            var exists = await _context.Wishlists.AnyAsync(w => w.UserId == userId && w.ProductId == productId);
            if (!exists)
            {
                var wishlist = new Wishlist { UserId = userId, ProductId = productId };
                _context.Wishlists.Add(wishlist);
                await _context.SaveChangesAsync();
            }
        }

        public async Task RemoveAsync(int wishlistId)
        {
            var item = await _context.Wishlists.FindAsync(wishlistId);
            if (item != null)
            {
                _context.Wishlists.Remove(item);
                await _context.SaveChangesAsync();
            }
        }
    }
}