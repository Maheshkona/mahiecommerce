using Bookory.Models;

namespace Bookory.Services
{
    /// <summary>
    /// Abstraction over product operations. Implementations are responsible
    /// for reading and writing product data from the database.
    /// </summary>
    public interface IProductService
    {
        Task<IEnumerable<Product>> GetAllAsync();
        Task<Product?> GetByIdAsync(int id);
        Task CreateAsync(Product product);
        Task UpdateAsync(Product product);
        Task DeleteAsync(int id);
    }
}