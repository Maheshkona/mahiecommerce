using System.Collections.Generic;

namespace BookStore.Models
{
    /// <summary>
    /// Represents a book category such as Fiction, Non‑fiction or
    /// Biographies.  Each book belongs to a single category.
    /// </summary>
    public class Category
    {
        public int CategoryId { get; set; }
        public string Name { get; set; } = string.Empty;
        public ICollection<Book> Books { get; set; } = new List<Book>();
    }
}