using System.Collections.Generic;

namespace BookStore.Models
{
    /// <summary>
    /// Represents a customer's shopping cart.  Each customer has at
    /// most one cart.  The cart contains multiple cart items which
    /// store the selected books and their quantities.
    /// </summary>
    public class Cart
    {
        public int CartId { get; set; }
        public int CustomerId { get; set; }
        public Customer? Customer { get; set; }
        public ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();
    }
}