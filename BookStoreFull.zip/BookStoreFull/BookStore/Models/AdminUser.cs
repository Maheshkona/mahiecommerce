namespace BookStore.Models
{
    /// <summary>
    /// Represents an administrator for the store.  Admins have
    /// privileges to manage products, view orders and customers.  In
    /// practice you would integrate with ASP.NET Core Identity to
    /// manage users and roles rather than storing passwords directly.
    /// </summary>
    public class AdminUser
    {
        public int AdminUserId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
    }
}