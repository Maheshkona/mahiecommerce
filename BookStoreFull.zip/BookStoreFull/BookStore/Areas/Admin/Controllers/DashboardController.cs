using Microsoft.AspNetCore.Mvc;

namespace BookStore.Areas.Admin.Controllers
{
    /// <summary>
    /// Dashboard for administrators showing key metrics.  This
    /// controller lives in the Admin area which is defined by the
    /// [Area] attribute on the class.  Routes will be prefixed with
    /// /Admin.
    /// </summary>
    [Area("Admin")]
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}