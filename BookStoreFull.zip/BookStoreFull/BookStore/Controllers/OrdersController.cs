using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    /// <summary>
    /// Displays the logged in customer's past orders.  Orders are
    /// stored client side in the demo; in a production system you
    /// would query the database and show real order history.
    /// </summary>
    public class OrdersController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}