using System.Linq;
using System.Threading.Tasks;
using BookStore.Data;
using BookStore.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Services
{
    /// <summary>
    /// Provides CRUD operations for a user's shopping cart.  This
    /// implementation automatically creates a cart if one does not
    /// exist for the user.
    /// </summary>
    public class CartService : ICartService
    {
        private readonly AppDbContext _context;
        public CartService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Cart> GetCartAsync(int userId)
        {
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                    .ThenInclude(ci => ci.Book)
                .FirstOrDefaultAsync(c => c.CustomerId == userId);
            if (cart == null)
            {
                cart = new Cart { CustomerId = userId };
                _context.Carts.Add(cart);
                await _context.SaveChangesAsync();
            }
            return cart;
        }

        public async Task AddItemAsync(int userId, int bookId, int quantity)
        {
            var cart = await GetCartAsync(userId);
            var existing = cart.CartItems.FirstOrDefault(ci => ci.BookId == bookId);
            if (existing != null)
            {
                existing.Quantity += quantity;
            }
            else
            {
                cart.CartItems.Add(new CartItem
                {
                    BookId = bookId,
                    Quantity = quantity
                });
            }
            await _context.SaveChangesAsync();
        }

        public async Task RemoveItemAsync(int cartItemId)
        {
            var item = await _context.CartItems.FindAsync(cartItemId);
            if (item != null)
            {
                _context.CartItems.Remove(item);
                await _context.SaveChangesAsync();
            }
        }

        public async Task ClearCartAsync(int userId)
        {
            var cart = await GetCartAsync(userId);
            _context.CartItems.RemoveRange(cart.CartItems);
            await _context.SaveChangesAsync();
        }
    }
}