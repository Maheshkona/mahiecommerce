using System.Threading.Tasks;
using BookStore.Models;

namespace BookStore.Services
{
    /// <summary>
    /// Defines operations for managing users including authentication
    /// and profile management.
    /// </summary>
    public interface IUserService
    {
        Task<Customer> RegisterAsync(Customer customer);
        Task<Customer?> LoginAsync(string emailOrUsername, string password);
        Task<Customer?> GetProfileAsync(int customerId);
        Task<bool> UpdateProfileAsync(int customerId, Customer updated);
    }
}