namespace BookStore.Models
{
    /// <summary>
    /// Represents a link between a wishlist and a book.  Each
    /// WishlistItem stores the identifier of the wishlist and the
    /// associated book.  This allows many books to be stored in a
    /// single wishlist and the same book to exist in multiple
    /// wishlists.
    /// </summary>
    public class WishlistItem
    {
        public int WishlistItemId { get; set; }
        public int WishlistId { get; set; }
        public Wishlist? Wishlist { get; set; }
        public int BookId { get; set; }
        public Book? Book { get; set; }
    }
}