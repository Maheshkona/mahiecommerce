namespace BookStore.Models
{
    /// <summary>
    /// Represents an item in a customer's shopping cart.  Stores the
    /// selected book and quantity.  When an order is placed the
    /// contents of the cart are transformed into OrderItems.
    /// </summary>
    public class CartItem
    {
        public int CartItemId { get; set; }
        public int CartId { get; set; }
        public Cart? Cart { get; set; }
        public int BookId { get; set; }
        public Book? Book { get; set; }
        public int Quantity { get; set; }
    }
}