using System.Collections.Generic;

namespace BookStore.Models
{
    /// <summary>
    /// Represents a book product in the store.  A book has a title,
    /// author, description, price and associated image URL.  Books
    /// belong to categories and can appear in a customer's cart,
    /// wishlist or order.  The relationships to other entities are
    /// defined through navigation properties.
    /// </summary>
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public string ImageUrl { get; set; } = string.Empty;

        // Foreign key to Category
        public int CategoryId { get; set; }
        public Category? Category { get; set; }

        // Navigation properties for many‑to‑many relationships
        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
        public ICollection<WishlistItem> WishlistItems { get; set; } = new List<WishlistItem>();
        public ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();
    }
}