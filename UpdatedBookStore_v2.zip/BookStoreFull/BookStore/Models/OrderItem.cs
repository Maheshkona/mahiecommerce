namespace BookStore.Models
{
    /// <summary>
    /// Represents an individual line item within an order.  Each
    /// OrderItem links a specific book to an order along with the
    /// quantity and unit price at the time of purchase.
    /// </summary>
    public class OrderItem
    {
        public int OrderItemId { get; set; }
        public int OrderId { get; set; }
        public Order? Order { get; set; }
        public int BookId { get; set; }
        public Book? Book { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
    }
}