using Microsoft.AspNetCore.Mvc;

namespace BookStore.Areas.Admin.Controllers
{
    /// <summary>
    /// Dashboard for administrators showing key metrics.  This
    /// controller lives in the Admin area which is defined by the
    /// [Area] attribute on the class.  Routes will be prefixed with
    /// /Admin.
    /// </summary>
    [Area("Admin")]
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            // Simple role check: only allow users with ADMIN role
            if (!Request.Cookies.TryGetValue("Role", out var role) || role != "ADMIN")
            {
                return RedirectToAction("Login", "Account", new { area = "" });
            }
            return View();
        }
    }
}