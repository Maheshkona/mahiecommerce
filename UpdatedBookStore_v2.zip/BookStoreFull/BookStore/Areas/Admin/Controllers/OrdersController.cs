using Microsoft.AspNetCore.Mvc;

namespace BookStore.Areas.Admin.Controllers
{
    /// <summary>
    /// Administration of orders.  Allows an administrator to view
    /// orders placed by customers, update their statuses and see
    /// details.
    /// </summary>
    [Area("Admin")]
    public class OrdersController : Controller
    {
        public IActionResult Index()
        {
            if (!Request.Cookies.TryGetValue("Role", out var role) || role != "ADMIN")
            {
                return RedirectToAction("Login", "Account", new { area = "" });
            }
            return View();
        }
    }
}