using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    /// <summary>
    /// Collects shipping details and summarises the order before
    /// payment.  In a real application this would display the user's
    /// saved addresses and allow them to select or add new ones.
    /// </summary>
    public class CheckoutController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}