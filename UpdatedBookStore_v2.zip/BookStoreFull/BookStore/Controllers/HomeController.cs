using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    /// <summary>
    /// The home controller is responsible for rendering the public
    /// landing page.  Additional actions could be added here for
    /// privacy policy, about or contact pages.
    /// </summary>
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}