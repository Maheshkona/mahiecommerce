using Microsoft.AspNetCore.Mvc;

namespace BookStore.Controllers
{
    /// <summary>
    /// Handles the payment workflow.  Index shows the payment form
    /// while Success displays confirmation once the mock payment is
    /// complete.
    /// </summary>
    public class PaymentController : Controller
    {
        private readonly BookStore.Services.IPaymentService _paymentService;
        private readonly BookStore.Services.IOrderService _orderService;

        public PaymentController(BookStore.Services.IPaymentService paymentService,
                                 BookStore.Services.IOrderService orderService)
        {
            _paymentService = paymentService;
            _orderService = orderService;
        }

        /// <summary>
        /// Display the payment form for a given order.  This loads the order
        /// from the database so the view can show the total and order items.
        /// </summary>
        public async Task<IActionResult> Index(int orderId)
        {
            var order = await _orderService.GetOrderByIdAsync(orderId);
            if (order == null)
            {
                return NotFound();
            }
            return View(order);
        }

        /// <summary>
        /// Processes the payment.  Accepts the orderId and the selected
        /// payment method from the posted form.  Uses the payment service
        /// to record the payment and marks the order as paid.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Process(int orderId, string paymentMethod)
        {
            var order = await _orderService.GetOrderByIdAsync(orderId);
            if (order == null)
            {
                return NotFound();
            }
            // Use total amount from order
            var payment = await _paymentService.ProcessPaymentAsync(orderId, order.TotalAmount, paymentMethod);
            return RedirectToAction("Success", new { paymentId = payment.PaymentId });
        }

        /// <summary>
        /// Shows a simple payment success page.  If a paymentId is provided
        /// the view will display the payment details.
        /// </summary>
        public async Task<IActionResult> Success(int? paymentId)
        {
            BookStore.Models.Payment? payment = null;
            if (paymentId.HasValue)
            {
                payment = await _paymentService.GetPaymentStatusAsync(paymentId.Value);
            }
            return View(payment);
        }
    }
}