using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace BookStore.Controllers
{
    /// <summary>
    /// Handles the shopping cart page.  Cart interactions (adding,
    /// updating quantities and removing items) happen client side via
    /// JavaScript in this example.  In a production system you would
    /// persist the cart on the server and perform updates through
    /// controller actions and API endpoints.
    /// </summary>
    public class CartController : Controller
    {
        private readonly BookStore.Services.ICartService _cartService;
        public CartController(BookStore.Services.ICartService cartService)
        {
            _cartService = cartService;
        }
        // Display the cart for the current user.  UserId is read from the auth cookie.
        public async Task<IActionResult> Index()
        {
            int userId = 0;
            if (Request.Cookies.TryGetValue("UserId", out var uid) && int.TryParse(uid, out var parsed))
            {
                userId = parsed;
            }
            else
            {
                // no user: redirect to login
                return RedirectToAction("Login", "Account");
            }
            var cart = await _cartService.GetCartAsync(userId);
            return View(cart);
        }
        // Add a book to the cart
        [HttpPost]
        public async Task<IActionResult> Add(int bookId, int quantity = 1)
        {
            if (!Request.Cookies.TryGetValue("UserId", out var uid) || !int.TryParse(uid, out var userId))
            {
                return RedirectToAction("Login", "Account");
            }
            await _cartService.AddItemAsync(userId, bookId, quantity);
            return RedirectToAction("Index");
        }
        // Remove an item from the cart
        [HttpPost]
        public async Task<IActionResult> Remove(int cartItemId)
        {
            await _cartService.RemoveItemAsync(cartItemId);
            return RedirectToAction("Index");
        }
        // Clear the cart
        [HttpPost]
        public async Task<IActionResult> Clear()
        {
            if (!Request.Cookies.TryGetValue("UserId", out var uid) || !int.TryParse(uid, out var userId))
            {
                return RedirectToAction("Login", "Account");
            }
            await _cartService.ClearCartAsync(userId);
            return RedirectToAction("Index");
        }
    }
}