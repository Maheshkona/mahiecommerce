using System.Threading.Tasks;
using BookStore.Models;

namespace BookStore.Services
{
    /// <summary>
    /// Defines payment processing operations.
    /// </summary>
    public interface IPaymentService
    {
        Task<Payment> ProcessPaymentAsync(int orderId, decimal amount, string method);
        Task<Payment?> GetPaymentStatusAsync(int paymentId);
    }
}