using System;
using System.Threading.Tasks;
using BookStore.Data;
using BookStore.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Services
{
    /// <summary>
    /// Mock payment service implementation.  In production this
    /// would call an external payment gateway and update the order
    /// accordingly.
    /// </summary>
    public class PaymentService : IPaymentService
    {
        private readonly AppDbContext _context;
        public PaymentService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<Payment> ProcessPaymentAsync(int orderId, decimal amount, string method)
        {
            // simulate payment success
            var payment = new Payment
            {
                OrderId = orderId,
                Amount = amount,
                PaymentMethod = method,
                PaymentStatus = "COMPLETED",
                PaymentDate = DateTime.UtcNow
            };
            _context.Payments.Add(payment);
            // update order status
            var order = await _context.Orders.FindAsync(orderId);
            if (order != null)
            {
                order.Status = "PAID";
            }
            await _context.SaveChangesAsync();
            return payment;
        }
        public async Task<Payment?> GetPaymentStatusAsync(int paymentId)
        {
            return await _context.Payments.FirstOrDefaultAsync(p => p.PaymentId == paymentId);
        }
    }
}