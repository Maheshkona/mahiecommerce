using System.Collections.Generic;
using System.Threading.Tasks;
using BookStore.Models;

namespace BookStore.Services
{
    /// <summary>
    /// Defines operations for managing books.
    /// </summary>
    public interface IBookService
    {
        Task<Book> AddBookAsync(Book book);
        Task<Book?> GetBookByIdAsync(int id);
        Task<IEnumerable<Book>> GetAllBooksAsync();
        Task<Book?> UpdateBookAsync(int id, Book updated);
        Task<bool> DeleteBookAsync(int id);
    }
}