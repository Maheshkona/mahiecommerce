using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookStore.Data;
using BookStore.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Services
{
    /// <summary>
    /// Provides order management including creation, retrieval and
    /// status updates.  In a real system this would handle
    /// transactions, inventory checks and payment integration.
    /// </summary>
    public class OrderService : IOrderService
    {
        private readonly AppDbContext _context;
        public OrderService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<Order> CreateOrderAsync(int customerId)
        {
            // For demonstration, build order from cart items and
            // clear the cart.  In a real application you would
            // calculate totals and handle payment.
            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .FirstOrDefaultAsync(c => c.CustomerId == customerId);
            if (cart == null || !cart.CartItems.Any())
            {
                throw new InvalidOperationException("Cart is empty or does not exist.");
            }
            var order = new Order
            {
                CustomerId = customerId,
                OrderDate = DateTime.UtcNow,
                Status = "PENDING",
                TotalAmount = cart.CartItems.Sum(ci => ci.Quantity * (ci.Book?.Price ?? 0))
            };
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            // Convert cart items to order items
            foreach (var ci in cart.CartItems)
            {
                var oi = new OrderItem
                {
                    OrderId = order.OrderId,
                    BookId = ci.BookId,
                    Quantity = ci.Quantity,
                    UnitPrice = ci.Book?.Price ?? 0
                };
                _context.OrderItems.Add(oi);
            }
            // Clear cart
            _context.CartItems.RemoveRange(cart.CartItems);
            await _context.SaveChangesAsync();
            return order;
        }

        public async Task<Order?> GetOrderByIdAsync(int orderId)
        {
            return await _context.Orders
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Book)
                .Include(o => o.Payment)
                .FirstOrDefaultAsync(o => o.OrderId == orderId);
        }

        public async Task<IEnumerable<Order>> ListOrdersAsync(int? customerId = null)
        {
            var query = _context.Orders
                .Include(o => o.OrderItems)
                .AsQueryable();
            if (customerId.HasValue)
            {
                query = query.Where(o => o.CustomerId == customerId.Value);
            }
            return await query.ToListAsync();
        }

        public async Task<bool> UpdateStatusAsync(int orderId, string status)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order == null)
            {
                return false;
            }
            order.Status = status;
            await _context.SaveChangesAsync();
            return true;
        }
    }
}