using System;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using BookStore.Data;
using BookStore.Models;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Services
{
    /// <summary>
    /// Provides user registration, login and profile operations.
    /// Note: This is a simple example that uses SHA256 hashing.
    /// In production you should use a stronger algorithm and salt.
    /// </summary>
    public class UserService : IUserService
    {
        private readonly AppDbContext _context;
        public UserService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<Customer> RegisterAsync(Customer customer)
        {
            // ensure username is provided
            if (string.IsNullOrWhiteSpace(customer.Username))
            {
                throw new ArgumentException("Username must be provided");
            }
            // ensure email is provided
            if (string.IsNullOrWhiteSpace(customer.Email))
            {
                throw new ArgumentException("Email must be provided");
            }
            // check for duplicate username or email
            if (await _context.Customers.AnyAsync(c => c.Username == customer.Username))
            {
                throw new ArgumentException("Username already exists");
            }
            if (await _context.Customers.AnyAsync(c => c.Email == customer.Email))
            {
                throw new ArgumentException("Email already exists");
            }
            // hash password
            customer.PasswordHash = HashPassword(customer.PasswordHash);
            // default to CUSTOMER role if not specified
            if (string.IsNullOrEmpty(customer.Role))
            {
                customer.Role = "CUSTOMER";
            }
            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();
            return customer;
        }

        public async Task<Customer?> LoginAsync(string emailOrUsername, string password)
        {
            var hash = HashPassword(password);
            // allow login by username or email
            return await _context.Customers.FirstOrDefaultAsync(c =>
                (c.Email == emailOrUsername || c.Username == emailOrUsername) && c.PasswordHash == hash);
        }
        public async Task<Customer?> GetProfileAsync(int customerId)
        {
            return await _context.Customers
                .Include(c => c.Addresses)
                .Include(c => c.Orders)
                .FirstOrDefaultAsync(c => c.CustomerId == customerId);
        }
        public async Task<bool> UpdateProfileAsync(int customerId, Customer updated)
        {
            var existing = await _context.Customers.FindAsync(customerId);
            if (existing == null)
            {
                return false;
            }
            existing.Name = updated.Name;
            existing.Email = updated.Email;
            existing.Username = updated.Username;
            if (!string.IsNullOrEmpty(updated.PasswordHash))
            {
                existing.PasswordHash = HashPassword(updated.PasswordHash);
            }
            existing.Phone = updated.Phone;
            // Do not update Role here to prevent privilege escalation.
            await _context.SaveChangesAsync();
            return true;
        }
        private static string HashPassword(string password)
        {
            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
            return BitConverter.ToString(bytes).Replace("-", "").ToLower();
        }
    }
}