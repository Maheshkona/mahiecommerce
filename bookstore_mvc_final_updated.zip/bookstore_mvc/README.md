# BookStore MVC Application

This repository contains a complete e‑commerce web application for a book store built on **ASP.NET 8 MVC** with **Entity Framework Core**. The application follows a clean MVC architecture and demonstrates how to manage products (books), user shopping carts, orders, payments and user accounts with role‑based access (admin and customer).

## Features

### User Facing

* Browse books by category or view all books.
* View detailed information for each book.
* Register and log in with cookie‑based authentication.
* Add books to a shopping cart, update quantities and remove items.
* Checkout to create orders; a mock payment is recorded for every order.
* View a list of your past orders and inspect order details.

### Administration

* Admin users can manage the catalogue: create, edit and delete books.
* Dashboard with basic statistics: number of users, books, orders and total sales.
* View all orders placed by customers and update their status (`PENDING`, `SHIPPED`, `DELIVERED`, `CANCELLED`).

## Getting Started

This project uses **SQLite** for local development and targets **.NET 8**. If you have the .NET 8 SDK installed you can run the application with the following steps:

1. Navigate to the project folder:

   ```bash
   cd bookstore_mvc
   ```

2. Restore NuGet packages and build the project:

   ```bash
   dotnet restore
   dotnet build
   ```

3. Apply migrations (the application will automatically apply migrations and seed the database on startup). Alternatively you can manually create the SQLite file using the included SQL script:

   ```bash
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   ```

4. Run the application:

   ```bash
   dotnet run
   ```

5. Open your browser and navigate to `https://localhost:5001` (or the URL shown in the console). You should see the home page listing a few sample books.

### Default Admin Credentials

The database seeding logic creates one admin user with the following credentials:

* **Username:** `admin`
* **Password:** `Admin@123`

Log in with these credentials to access the administration dashboard and manage books and orders.

## Database Schema

The database schema is defined by Entity Framework Core models. A simplified SQL version of the schema can be found in `database_schema.sql`. The main tables include:

| Table | Purpose |
|------|---------|
| **Users** | Stores user accounts with hashed passwords and roles (`CUSTOMER` or `ADMIN`). |
| **Categories** | Book categories (e.g., Fiction, Science). |
| **Books** | Product catalogue with title, description, price, category, stock quantity and image URL. |
| **CartItems** | Temporary cart items per user. |
| **Orders** | Orders placed by users with total amount, date and status. |
| **OrderItems** | Each book item within an order. |
| **Payments** | Mock payment records for orders with amount, status and date. |

## Customisation

* **Switching to SQL Server:** Update the connection string in `appsettings.json` to point to a SQL Server instance and replace the `UseSqlite` call with `UseSqlServer` in `Program.cs`.
* **Adding Real Payment Processing:** The `Payment` logic currently marks all payments as `COMPLETED`. Integrate with a real payment gateway by implementing the `Payment` model and controller accordingly.
* **Extending User Management:** You can replace the simple user system with ASP.NET Identity for more robust account management, password reset, email confirmation, etc.

## Screenshots

The images used in the sample book catalogue (`great_gatsby.jpg`, `brief_history_of_time.jpg`, `clean_code.jpg`) are abstract generative covers created for this demo. A placeholder (`default-book.png`) is used when no image is specified.

## License

This project is provided for educational purposes and does not include any proprietary content. You are free to modify and extend it as needed.