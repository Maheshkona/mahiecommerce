using ECommercePlatform.Data;
using ECommercePlatform.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommercePlatform.Controllers
{
    /// <summary>
    /// Integrates a mock payment gateway.  In a production system this
    /// controller would call out to a real payment provider.  For local
    /// testing we simply mark the payment as completed and update the
    /// associated order to a new status.
    /// </summary>
    [Authorize]
    public class PaymentController : Controller
    {
        private readonly AppDbContext _context;

        public PaymentController(AppDbContext context)
        {
            _context = context;
        }

        // GET: /Payment/Process/5
        public async Task<IActionResult> Process(int orderId)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order == null)
            {
                return NotFound();
            }
            // Create a payment record.  In a real integration the status
            // would depend on the gateway response.
            var payment = new Payment
            {
                OrderId = orderId,
                Amount = order.TotalAmount,
                PaymentStatus = "COMPLETED",
                PaymentDate = DateTime.UtcNow
            };
            _context.Payments.Add(payment);
            // Advance the order status
            order.Status = "SHIPPED";
            await _context.SaveChangesAsync();
            return RedirectToAction("Details", "Order", new { id = orderId });
        }

        // GET: /Payment/Status/5
        public async Task<IActionResult> Status(int id)
        {
            var payment = await _context.Payments.FindAsync(id);
            if (payment == null)
            {
                return NotFound();
            }
            return View(payment);
        }
    }
}