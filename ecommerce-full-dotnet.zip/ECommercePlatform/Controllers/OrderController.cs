using ECommercePlatform.Data;
using ECommercePlatform.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ECommercePlatform.Controllers
{
    /// <summary>
    /// Handles order creation, retrieval and status updates.  Customers
    /// create orders based off their cart contents; administrators
    /// can update order statuses (e.g. marking as shipped).  Order
    /// details include any associated payments.
    /// </summary>
    [Authorize]
    public class OrderController : Controller
    {
        private readonly AppDbContext _context;

        public OrderController(AppDbContext context)
        {
            _context = context;
        }

        // GET: /Order
        public async Task<IActionResult> Index()
        {
            var userId = int.Parse(User.Claims.First(c => c.Type == "UserId").Value);
            var orders = await _context.Orders
                .Where(o => o.UserId == userId)
                .ToListAsync();
            return View(orders);
        }

        // GET: /Order/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var order = await _context.Orders
                .Include(o => o.Payments)
                .FirstOrDefaultAsync(o => o.OrderId == id);
            if (order == null)
            {
                return NotFound();
            }
            return View(order);
        }

        // POST: /Order/Create
        [HttpPost]
        public async Task<IActionResult> Create()
        {
            var userId = int.Parse(User.Claims.First(c => c.Type == "UserId").Value);
            var cartItems = await _context.Carts
                .Include(c => c.Product)
                .Where(c => c.UserId == userId)
                .ToListAsync();
            if (!cartItems.Any())
            {
                TempData["Message"] = "Your cart is empty.";
                return RedirectToAction("Index", "Cart");
            }
            decimal totalAmount = cartItems.Sum(item => (item.Product!.Price * item.Quantity));
            var order = new Order
            {
                UserId = userId,
                TotalAmount = totalAmount,
                OrderDate = DateTime.UtcNow,
                Status = "PENDING"
            };
            _context.Orders.Add(order);
            // Clear the cart
            _context.Carts.RemoveRange(cartItems);
            await _context.SaveChangesAsync();
            return RedirectToAction("Details", new { id = order.OrderId });
        }

        // Only administrators should change order status
        [Authorize(Roles = "ADMIN")]
        public async Task<IActionResult> UpdateStatus(int id, string status)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }
            order.Status = status.ToUpperInvariant();
            await _context.SaveChangesAsync();
            return RedirectToAction("Details", new { id = order.OrderId });
        }
    }
}