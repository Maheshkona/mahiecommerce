using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommercePlatform.Models
{
    /// <summary>
    /// Represents a customer order.  An order records who placed the
    /// purchase, the total amount and current status.  The OrderDate is
    /// recorded in UTC to avoid timezone issues.
    /// </summary>
    public class Order
    {
        [Key]
        [Column("orderid")]
        public int OrderId { get; set; }

        [Column("userid")]
        public int UserId { get; set; }

        [Column("totalAmount", TypeName = "DECIMAL(10,2)")]
        public decimal TotalAmount { get; set; }

        [Column("orderDate")]
        public DateTime OrderDate { get; set; } = DateTime.UtcNow;

        [Column("status")]
        [StringLength(20)]
        public string Status { get; set; } = "PENDING";

        // Navigation properties
        public User? User { get; set; }
        public ICollection<Payment> Payments { get; set; } = new List<Payment>();
    }
}