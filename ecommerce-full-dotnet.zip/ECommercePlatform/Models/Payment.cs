using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommercePlatform.Models
{
    /// <summary>
    /// Represents a payment against an order.  For simplicity we record
    /// only one payment per order, but the model supports multiple
    /// payments (for partial payments or refunds) through the
    /// one‑to‑many relationship configured in the DbContext.
    /// </summary>
    public class Payment
    {
        [Key]
        [Column("paymentid")]
        public int PaymentId { get; set; }

        [Column("orderid")]
        public int OrderId { get; set; }

        [Column("amount", TypeName = "DECIMAL(10,2)")]
        public decimal Amount { get; set; }

        [Column("paymentStatus")]
        [StringLength(20)]
        public string PaymentStatus { get; set; } = "PENDING";

        [Column("paymentDate")]
        public DateTime PaymentDate { get; set; } = DateTime.UtcNow;

        // Navigation property
        public Order? Order { get; set; }
    }
}