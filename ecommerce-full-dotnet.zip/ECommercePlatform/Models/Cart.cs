using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ECommercePlatform.Models
{
    /// <summary>
    /// Represents an entry in a user's shopping cart.  Each row
    /// associates a product with a user and records the desired quantity.
    /// </summary>
    public class Cart
    {
        [Key]
        [Column("cartid")]
        public int CartId { get; set; }

        [Column("userid")]
        public int UserId { get; set; }

        [Column("productid")]
        public int ProductId { get; set; }

        [Column("quantity")]
        public int Quantity { get; set; }

        // Navigation properties
        public User? User { get; set; }
        public Product? Product { get; set; }
    }
}