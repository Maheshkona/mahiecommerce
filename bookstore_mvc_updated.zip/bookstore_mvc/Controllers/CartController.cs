using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookStoreMVC.Models;
using System.Security.Claims;

namespace BookStoreMVC.Controllers
{
    /// <summary>
    /// Handles shopping cart operations such as adding, updating, removing items and the checkout/payment flow.
    /// This controller requires the user to be authenticated.
    /// </summary>
    [Authorize]
    public class CartController : Controller
    {
        private readonly ApplicationDbContext _db;
        public CartController(ApplicationDbContext db) => _db = db;

        /// <summary>
        /// Retrieves the currently logged in user's numeric identifier from their claims.
        /// </summary>
        private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        // GET: /Cart
        public async Task<IActionResult> Index()
        {
            var items = await _db.CartItems
                .Include(c => c.Book).ThenInclude(b => b.Category)
                .Where(c => c.UserId == CurrentUserId)
                .OrderByDescending(c => c.Id)
                .ToListAsync();
            return View(items);
        }

        // GET: /Cart/Add/5
        /// <summary>
        /// Adds a book to the cart. If goToCart is true, user is redirected to the cart page; otherwise back to book details.
        /// </summary>
        public async Task<IActionResult> Add(int bookId, bool goToCart = true)
        {
            var book = await _db.Books.FindAsync(bookId);
            if (book == null || book.StockQuantity <= 0)
                return RedirectToAction("Index", "Books");

            var item = await _db.CartItems.FirstOrDefaultAsync(c => c.UserId == CurrentUserId && c.BookId == bookId);
            if (item == null)
            {
                item = new CartItem { UserId = CurrentUserId, BookId = bookId, Quantity = 1 };
                _db.CartItems.Add(item);
            }
            else
            {
                item.Quantity += 1;
            }
            await _db.SaveChangesAsync();
            return goToCart
                ? RedirectToAction("Index")
                : RedirectToAction("Details", "Books", new { id = bookId });
        }

        // GET: /Cart/Update/5?qty=2
        /// <summary>
        /// Updates the quantity of a cart item. Quantity is clamped between 1 and available stock.
        /// </summary>
        public async Task<IActionResult> Update(int id, int qty)
        {
            var item = await _db.CartItems.Include(c => c.Book)
                .FirstOrDefaultAsync(c => c.Id == id && c.UserId == CurrentUserId);
            if (item != null)
            {
                int maxQty = item.Book != null ? item.Book.StockQuantity : qty;
                item.Quantity = Math.Max(1, Math.Min(qty, maxQty));
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: /Cart/Remove/5
        /// <summary>
        /// Removes an item from the cart.
        /// </summary>
        public async Task<IActionResult> Remove(int id)
        {
            var item = await _db.CartItems.FirstOrDefaultAsync(c => c.Id == id && c.UserId == CurrentUserId);
            if (item != null)
            {
                _db.CartItems.Remove(item);
                await _db.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: /Cart/Checkout
        /// <summary>
        /// Displays the checkout form. Redirects to cart if there are no items.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Checkout()
        {
            bool hasItems = await _db.CartItems.AnyAsync(c => c.UserId == CurrentUserId);
            if (!hasItems)
            {
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        // POST: /Cart/Checkout
        /// <summary>
        /// Processes the checkout form and creates an order with PENDING status. Clears the cart and redirects to payment.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Checkout(CheckoutVm vm)
        {
            if (!ModelState.IsValid)
            {
                return View(vm);
            }
            var cart = await _db.CartItems.Include(c => c.Book)
                .Where(c => c.UserId == CurrentUserId).ToListAsync();
            if (!cart.Any())
            {
                return RedirectToAction(nameof(Index));
            }
            decimal total = cart.Sum(i => i.Book!.Price * i.Quantity);
            var order = new Order
            {
                UserId = CurrentUserId,
                OrderDate = DateTime.UtcNow,
                Status = OrderStatus.PENDING,
                TotalAmount = total,
                ShippingName = vm.FullName,
                ShippingAddress = vm.Address,
                ShippingCity = vm.City,
                ShippingState = vm.State,
                ShippingZip = vm.Zip,
                Phone = vm.Phone
            };
            _db.Orders.Add(order);
            await _db.SaveChangesAsync();
            // Convert cart items to order items
            foreach (var i in cart)
            {
                _db.OrderItems.Add(new OrderItem
                {
                    OrderId = order.Id,
                    BookId = i.BookId,
                    Quantity = i.Quantity,
                    UnitPrice = i.Book!.Price
                });
            }
            _db.CartItems.RemoveRange(cart);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Payment), new { orderId = order.Id });
        }

        // GET: /Cart/Payment
        /// <summary>
        /// Displays the payment form for the specified order.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Payment(int orderId)
        {
            var order = await _db.Orders.FindAsync(orderId);
            if (order == null || order.UserId != CurrentUserId)
            {
                return RedirectToAction("Index", "Books");
            }
            var vm = new PaymentVm { OrderId = orderId, Amount = order.TotalAmount };
            return View(vm);
        }

        // POST: /Cart/Payment
        /// <summary>
        /// Saves a payment record and updates the order status based on success. Redirects to success page.
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Payment(PaymentVm vm)
        {
            if (!ModelState.IsValid)
            {
                return View(vm);
            }
            var order = await _db.Orders.FindAsync(vm.OrderId);
            if (order == null || order.UserId != CurrentUserId)
            {
                return RedirectToAction("Index", "Books");
            }
            var payment = new Payment
            {
                OrderId = vm.OrderId,
                Amount = vm.Amount,
                PaymentStatus = vm.Success ? PaymentStatus.COMPLETED : PaymentStatus.FAILED,
                PaymentDate = DateTime.UtcNow
            };
            _db.Payments.Add(payment);
            order.Status = vm.Success ? OrderStatus.DELIVERED : OrderStatus.CANCELLED;
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Success), new { orderId = vm.OrderId, ok = vm.Success });
        }

        // GET: /Cart/Success
        /// <summary>
        /// Displays a summary of the completed order along with payment outcome.
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> Success(int orderId, bool ok = true)
        {
            var order = await _db.Orders
                .Include(o => o.OrderItems).ThenInclude(i => i.Book)
                .FirstOrDefaultAsync(o => o.Id == orderId && o.UserId == CurrentUserId);
            if (order == null)
            {
                return RedirectToAction("Index", "Books");
            }
            ViewBag.Ok = ok;
            return View(order);
        }
    }

    /// <summary>
    /// View model used for collecting shipping and contact details during checkout.
    /// </summary>
    public class CheckoutVm
    {
        public string FullName { get; set; } = "";
        public string Address { get; set; } = "";
        public string City { get; set; } = "";
        public string State { get; set; } = "";
        public string Zip { get; set; } = "";
        public string Phone { get; set; } = "";
    }

    /// <summary>
    /// View model used for processing payment. Includes a flag to simulate success or failure.
    /// </summary>
    public class PaymentVm
    {
        public int OrderId { get; set; }
        public decimal Amount { get; set; }
        public bool Success { get; set; } = true;
    }
}