-- SQL script to create the database schema for the BookStore MVC application.
-- This script is for illustrative purposes and matches the Entity Framework Core models.

CREATE TABLE "Users" (
    "Id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "Username" TEXT NOT NULL UNIQUE,
    "PasswordHash" TEXT NOT NULL,
    "Role" INTEGER NOT NULL,
    "Email" TEXT NOT NULL
);

CREATE TABLE "Categories" (
    "Id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "Name" TEXT NOT NULL
);

CREATE TABLE "Books" (
    "Id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "Title" TEXT NOT NULL,
    "Description" TEXT NOT NULL,
    "Price" DECIMAL(10,2) NOT NULL,
    "CategoryId" INTEGER NOT NULL,
    "StockQuantity" INTEGER NOT NULL,
    "ImageUrl" TEXT NOT NULL,
    FOREIGN KEY ("CategoryId") REFERENCES "Categories"("Id") ON DELETE CASCADE
);

CREATE TABLE "CartItems" (
    "Id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "UserId" INTEGER NOT NULL,
    "BookId" INTEGER NOT NULL,
    "Quantity" INTEGER NOT NULL,
    FOREIGN KEY ("UserId") REFERENCES "Users"("Id") ON DELETE CASCADE,
    FOREIGN KEY ("BookId") REFERENCES "Books"("Id") ON DELETE CASCADE
);

CREATE TABLE "Orders" (
    "Id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "UserId" INTEGER NOT NULL,
    "TotalAmount" DECIMAL(10,2) NOT NULL,
    "OrderDate" DATETIME NOT NULL,
    "Status" INTEGER NOT NULL,
    -- Shipping and contact information captured at checkout
    "ShippingName" TEXT,
    "ShippingAddress" TEXT,
    "ShippingCity" TEXT,
    "ShippingState" TEXT,
    "ShippingZip" TEXT,
    "Phone" TEXT,
    FOREIGN KEY ("UserId") REFERENCES "Users"("Id") ON DELETE CASCADE
);

CREATE TABLE "OrderItems" (
    "Id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "OrderId" INTEGER NOT NULL,
    "BookId" INTEGER NOT NULL,
    "Quantity" INTEGER NOT NULL,
    "UnitPrice" DECIMAL(10,2) NOT NULL,
    FOREIGN KEY ("OrderId") REFERENCES "Orders"("Id") ON DELETE CASCADE,
    FOREIGN KEY ("BookId") REFERENCES "Books"("Id") ON DELETE RESTRICT
);

CREATE TABLE "Payments" (
    "Id" INTEGER PRIMARY KEY AUTOINCREMENT,
    "OrderId" INTEGER NOT NULL,
    "Amount" DECIMAL(10,2) NOT NULL,
    -- PaymentStatus stored as text (e.g., COMPLETED, FAILED) for readability
    "PaymentStatus" TEXT NOT NULL,
    "PaymentDate" DATETIME NOT NULL,
    FOREIGN KEY ("OrderId") REFERENCES "Orders"("Id") ON DELETE CASCADE
);